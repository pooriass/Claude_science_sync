---
name: project-handoff
description: Keep a shared server project in sync between two people with separate Claude accounts, so either can see what was done and continue the other's work — even work cut off mid-task by a token limit. Use at the START of a session on a shared project ("resume", "what did my colleague do", "continue X's task"), when a pipeline is agreed ("apply this pipeline", "record/save this pipeline as a plan"), DURING work (runs, script edits, results), at the END ("handoff", "almost out of tokens"), and to ADOPT the system on a half-done project, including work scattered across Claude web chats and accounts.
---

# Project handoff

The project folder is the shared memory. Two people's Claude sessions never see each other's
chats; they meet in `<project>/.handoff/`. The helper `HS` = `<project>/.handoff/bin/handoff.sh`
does the bookkeeping (before adoption: `scripts/handoff.sh` in this skill). Every `HS` command
prints one short line; `HS help` lists them.

## Token rules (follow always)

- Start with **one** call: `HS brief`. It shows only what matters and what changed since this
  person's last brief. Do not also read STATE/CHECKPOINT/TODO/LOG files unless the brief points
  you to something you need.
- Open a reference file only in the situation listed at the bottom. Never "just in case".
- Write notes as short lines, not paragraphs: `-m "one to three lines"`. Use `HS cp` field flags
  (only changed fields) instead of rewriting CHECKPOINT. Use `Edit` on the changed lines of
  STATE.md, never a full rewrite.
- Never cat whole logs, scans or scripts. Use `HS show RUN` (errors + tails), `HS io SCRIPT`
  (read/write lines only), `grep`, `tail`.
- Don't poll running jobs in the chat. Start them, checkpoint, tell the user, check later.
- Combine: a step's result, tick and commit is one call: `HS plan step …`.

## 1. Start of session

1. `HS brief` (add `--no-scan` if the user says the folder is huge).
2. Lock: brief says free → `HS lock --task "…"`. Held by the other person and active → tell the
   user; take it only after the user confirms the other person stopped:
   `HS takeover --reason "<user's words>"`. STALE → tell the user, then takeover.
3. If the brief shows an interrupted task (checkpoint IN_PROGRESS/PAUSED by someone else, a
   DIED/FAILED run, uncommitted code) → read `references/resume-and-takeover.md` once, then act.
4. Tell the user in ≤6 lines: where things stand, anything odd, the next action. Ask to continue.

## 2. Pipelines: discuss → plan → apply

A pipeline agreed in discussion is saved as a **plan** before anything runs. The plan carries the
reasons, so the other person can apply or continue it without the chat.

- "Apply this pipeline" = save the plan, show it, wait for yes, then apply.
- "Save it as a plan / don't run yet" = save with `Status: agreed`, stop.
- Long discussion, or the user says "save a draft" = save with `Status: draft` + open questions.
- Discussed in a Claude web chat = the user pastes it; save it the same way, `Why:` says
  `[web-chat: NAME, DATE]`.

Save to `.handoff/plans/NN_short_name.md` (NN = next free number, see `HS plan list`) exactly in
this shape, then `HS plan set NN agreed -m "who agreed"`:

```
# Plan NN_short_name — title
Status: draft
Owner: NAME | Created: YYYY-MM-DD
Goal: one line
Why: 2–4 lines: the key reasons from the discussion
Rejected: option — reason; option — reason
Inputs: paths
Outputs: paths
Parameters: key=value, …
Environment: conda env / R version / container
## Steps
- [ ] 1. action (tool/package) → output path
- [ ] 2. …
## Success checks
- measurable check
## Open questions
- …
```

Use only methods and packages the discussion named or that are established for the task; do not
invent methodology. Show the user ≤8 lines (steps, key parameters, outputs) before applying.

**Apply, per step:**
1. `HS cp --plan "NN step k/n" --doing "…" --next "<exact command or check>"` (write-ahead).
2. Write or edit the script; then `HS commit "what changed" --add <new files>`.
3. Job over ~2 min → `HS run --name <name> -- <command>` (detached, survives the chat). Note the
   run id with `HS cp --runs "<id>"`. Short commands run directly.
4. Check the output briefly (exists, sane size, a few lines). Then
   `HS plan step NN k done -m "result in one line" --run <id>` (or `failed`, `skip`).
5. Need to deviate (error, parameter change)? Ask the user, then `HS plan amend NN -m "what and why"`.
   Never change a plan's method silently.
6. After the last step: compare with the success checks → `HS plan set NN done|failed -m "…"`.

Make long steps resumable: one output per sample/chunk, skip outputs that exist, write to `.tmp`
then rename. Prefer Snakemake/Nextflow for multi-step pipelines instead of hand-made engines.

**Work outside a plan** (a single fix, a one-off check): `HS log EDIT|RESULT|DECISION|FAIL|NOTE "title" -m "1–3 lines"`.
Log failures too, so nobody repeats them.

## 3. End of session

1. `Edit` only the lines of STATE.md that changed: *Current stage*, *Next step (exact command)*,
   *Known problems*. Don't list runs there (`brief` shows them live).
2. `HS cp --status IDLE` (task finished) or `HS cp --status PAUSED --next "<exact next action>"`.
3. `HS end -m "2–4 lines: done, running, next"`. Give the user a 3-line message for the colleague.

**Emergency ("almost out of tokens")** — two calls only:
`HS cp --status PAUSED --next "<exact next action>" --edited "<file: what's missing>"` then
`HS end --paused -m "<1 line>"`.

## Rules

- Never move, rename or delete existing project files; new versions get new names (`_v2`).
- Raw data is read-only. Don't trust outputs of DIED/KILLED runs until checked.
- Don't relaunch a RUNNING job. Stop a job only with the user's yes: `HS stop ID --reason "…"`.
- Web-chat results are "web-only, rerun needed" until regenerated on the server.
- No passwords, tokens or keys in any note or command.

## Read a reference only when

| Situation | File |
|---|---|
| Project has no `.handoff/config.env` (first time, incl. half-done projects) | `references/adoption-guide.md` |
| Work also happened in Claude web chats, laptops or other folders | `references/outside-work.md` |
| Interrupted task, DIED/FAILED run, half-edited code, takeover, parallel work | `references/resume-and-takeover.md` |
| Unsure how to word a log entry, STATE.md or DECISIONS entry | `references/file-formats.md` |
