#!/usr/bin/env bash
# =============================================================================
# handoff.sh — shared-project handoff helper (part of the "project-handoff" skill)
#
# Lets two people (two Claude accounts, two Unix users) work on ONE project
# folder on ONE server and pick up each other's work, including work that was
# cut off in the middle (token limit, crash, closed laptop).
#
# Everything lives in <project>/.handoff/ . Existing project files are never
# moved, renamed or deleted by this script.
#
# Usage:  handoff.sh [--root DIR] <command> [args]
#   brief [--no-scan]               START HERE each session: what changed since YOUR last brief
#   adopt DIR [--history] [--md5]   Start using handoff on a project (new OR mid-way); prints a summary
#   summary                         Compact overview of the adoption scan
#   io SCRIPT...                    Only the read/write/load/save lines of scripts
#   plan list | show N [--full] | set N STATUS [-m why] | step N K done|failed|skip [-m res] [--run ID] | amend N -m text
#   cp [--personal] --status S --task T --plan P --doing D --runs R --edited E --next X --note N [--clear]
#                                   Update only the given checkpoint fields (cheap write-ahead note)
#   rescan                          Re-inventory files; report what changed since last scan
#   status                          One-screen summary: lock, checkpoint, runs, git, log, todo
#   lock [--task TEXT] [--force]    Claim the project for this session
#   heartbeat                       Refresh your lock timestamp
#   unlock                          Release your lock
#   takeover --reason TEXT          Take the lock from someone else (logged)
#   log TYPE TITLE [-m BODY]        Append an entry to LOG.md and commit (body via -m or stdin)
#   checkpoint [--personal] (body on stdin) Replace CHECKPOINT.md (or CHECKPOINT_<you>.md) and commit
#   run --name N [--foreground] [--cwd D] [--note T] -- CMD ARGS...
#                                   Run a job detached, with logs + status files
#   runs [--all]                    List runs with live status (RUNNING/DONE/FAILED/DIED/KILLED)
#   show RUN_ID                     Show meta + last lines of a run's stdout/stderr
#   stop RUN_ID --reason TEXT       Send SIGTERM to a run's process group (logged)
#   manifest PATH ROLE [DESCRIPTION...]  Record a data file (size, md5, who, when)
#   commit MSG [--add PATH...]      Commit handoff files (+ code changes)
#   end [--paused] [-m SUMMARY]     Log HANDOFF, commit, release lock
#   perms                           Check shared-permission setup; print fix commands
#   history                         (opt-in) Save YOUR OWN shell/R/python history lines about this project
#   version
# Env: HANDOFF_ROOT (project dir), HANDOFF_USER (name shown in logs; default: Unix user)
# =============================================================================
set -uo pipefail
umask 002
HV="2.0"
SELF="$(readlink -f "${BASH_SOURCE[0]}")"

die(){ echo "ERROR: $*" >&2; exit 1; }
warn(){ echo "WARN: $*" >&2; }
ts(){ date '+%Y-%m-%d %H:%M:%S %Z'; }
ts_compact(){ date '+%Y%m%d-%H%M%S'; }
epoch(){ date +%s; }
me(){ echo "${HANDOFF_USER:-$(id -un)}"; }
host(){ hostname -s 2>/dev/null || hostname; }
human_age(){ local s=$1; if (( s<120 )); then echo "${s}s"; elif (( s<7200 )); then echo "$((s/60))m"; elif (( s<172800 )); then echo "$((s/3600))h"; else echo "$((s/86400))d"; fi; }

ROOT=""
find_root(){
  [[ -n "$ROOT" ]] && return
  if [[ -n "${HANDOFF_ROOT:-}" ]]; then ROOT="$HANDOFF_ROOT"; return; fi
  local d="$PWD"
  while [[ "$d" != "/" ]]; do
    [[ -d "$d/.handoff" ]] && { ROOT="$d"; return; }
    d="$(dirname "$d")"
  done
  die "No .handoff/ found from $PWD upward. Use --root DIR, set HANDOFF_ROOT, or run 'adopt DIR' first."
}
setup(){
  find_root
  ROOT="$(cd "$ROOT" 2>/dev/null && pwd -P)" || die "Project root not accessible: $ROOT"
  H="$ROOT/.handoff"
  [[ -d "$H" ]] || die "$ROOT has no .handoff/ — run: handoff.sh adopt $ROOT"
  load_config
}
load_config(){
  PROJECT_NAME="$(basename "$ROOT")"; STALE_LOCK_HOURS=3; MD5_MAX_MB=200; EXTRA_PATHS=""
  SCAN_EXCLUDE=".git .handoff .snakemake work renv/library __pycache__ .ipynb_checkpoints node_modules .Rproj.user .venv venv .cache"
  # shellcheck disable=SC1091
  [[ -f "$H/config.env" ]] && source "$H/config.env"
}

# ---- serialized writes (two people may append at the same moment) ----------
with_lock(){
  if command -v flock >/dev/null 2>&1; then
    ( flock -w 30 9 || { echo "ERROR: could not get write lock" >&2; exit 1; }; "$@" ) 9>>"$H/.write.lock"
  else "$@"; fi
}

# ---- git ---------------------------------------------------------------------
g(){ git -c safe.directory="$ROOT" -c safe.directory='*' -C "$ROOT" "$@"; }
has_git(){ command -v git >/dev/null 2>&1 && g rev-parse --git-dir >/dev/null 2>&1; }
git_mode(){ cat "$H/.git_mode" 2>/dev/null || echo none; }
do_commit(){  # $1 = message ; extra args = paths to add explicitly
  local msg="$1"; shift || true
  has_git || return 0
  g add -A -- .handoff >/dev/null 2>&1 || true
  # code is committed only by the explicit 'commit' command (CODE=1), so a half-finished
  # edit stays visible as "uncommitted" to the next person
  if [[ "${CODE:-0}" == 1 ]]; then
    if [[ "$(git_mode)" == "handoff-owned" ]]; then g add -A . >/dev/null 2>&1 || true   # whitelist keeps data out
    else g add -u -- . >/dev/null 2>&1 || true; fi                                     # existing repo: tracked only
  fi
  local p; for p in "$@"; do g add -- "$p" >/dev/null 2>&1 || warn "could not git-add $p"; done
  g diff --cached --quiet 2>/dev/null && return 0
  if g -c user.name="$(me)" -c user.email="$(me)@$(host)" commit -q -m "[$(me)] $msg" >/dev/null 2>&1; then
    COMMIT_SHORT="$(g rev-parse --short HEAD 2>/dev/null)"
    [[ -n "${HANDOFF_VERBOSE:-}" ]] && echo "git: committed [$(me)] $msg ($COMMIT_SHORT)"
  else warn "git commit failed (check: git -C $ROOT status)"; fi
  return 0
}
COMMIT_SHORT=""
gitnote(){ [[ -n "$COMMIT_SHORT" ]] && printf ' · git %s' "$COMMIT_SHORT"; return 0; }

# ---- lock ---------------------------------------------------------------------
lock_get(){ [[ -f "$H/LOCK" ]] && grep -m1 "^$1=" "$H/LOCK" | cut -d= -f2-; }
lock_state(){  # prints: free | mine | active | stale
  [[ -s "$H/LOCK" ]] || { echo free; return; }
  local u hb; u="$(lock_get user)"; hb="$(lock_get heartbeat)"; hb=${hb:-0}
  if [[ "$u" == "$(me)" ]]; then echo mine; return; fi
  if (( $(epoch) - hb > STALE_LOCK_HOURS*3600 )); then echo stale; else echo active; fi
}
write_lock(){  # $1 task
  local since; since="$(lock_get since)"
  [[ "$(lock_get user)" == "$(me)" && -n "$since" ]] || since="$(epoch)"
  local task="${1:-$(lock_get task)}"
  cat > "$H/LOCK.tmp" <<EOF
user=$(me)
host=$(host)
unix_user=$(id -un)
since=$since
heartbeat=$(epoch)
heartbeat_h=$(ts)
task=$task
EOF
  mv -f "$H/LOCK.tmp" "$H/LOCK"
}
heartbeat_if_mine(){ [[ "$(lock_state)" == mine ]] && write_lock "" ; return 0; }
warn_if_other_lock(){
  local s; s="$(lock_state)"
  if [[ "$s" == active ]]; then
    warn "project is LOCKED by $(lock_get user) (task: $(lock_get task); heartbeat $(human_age $(( $(epoch)-$(lock_get heartbeat) ))) ago). Coordinate before changing shared files."
  fi
}
cmd_lock(){
  local task="" force=0
  while [[ $# -gt 0 ]]; do case "$1" in --task) task="$2"; shift 2;; --force) force=1; shift;; *) die "lock: unknown arg $1";; esac; done
  local s; s="$(lock_state)"
  case "$s" in
    free|mine) write_lock "$task"; echo "LOCK: held by $(me) (task: ${task:-$(lock_get task)})";;
    active) if (( force )); then cmd_takeover --reason "forced lock (--force) by $(me)"; else
              echo "LOCK: ACTIVE, held by $(lock_get user)@$(lock_get host) since $(date -d @"$(lock_get since)" '+%F %R' 2>/dev/null), last heartbeat $(human_age $(( $(epoch)-$(lock_get heartbeat) ))) ago, task: $(lock_get task)"
              echo "Not taking it. If they are finished or out of tokens, run: handoff.sh takeover --reason \"...\""; exit 3; fi;;
    stale) echo "LOCK: STALE (held by $(lock_get user), no heartbeat for > ${STALE_LOCK_HOURS}h)."
           echo "Run: handoff.sh takeover --reason \"...\"  (it will be logged)"; exit 4;;
  esac
}
cmd_unlock(){
  local s; s="$(lock_state)"
  if [[ "$s" == mine ]]; then rm -f "$H/LOCK"; echo "LOCK: released"
  elif [[ "$s" == free ]]; then echo "LOCK: already free"
  else die "lock belongs to $(lock_get user); use takeover instead of unlock"; fi
}
cmd_takeover(){
  local reason=""
  while [[ $# -gt 0 ]]; do case "$1" in --reason) reason="$2"; shift 2;; *) die "takeover: unknown arg $1";; esac; done
  [[ -n "$reason" ]] || die "takeover needs --reason \"...\""
  local prev="none"
  [[ -s "$H/LOCK" ]] && prev="$(lock_get user)@$(lock_get host), task: $(lock_get task), last heartbeat: $(lock_get heartbeat_h)"
  write_lock "$(lock_get task)"
  printf 'Previous holder: %s\nReason: %s\n' "$prev" "$reason" | append_log TAKEOVER "lock taken over by $(me)"
  do_commit "takeover: $reason"
  echo "ok: lock now $(me) (was: $prev)$(gitnote)"
}

# ---- log / checkpoint -------------------------------------------------------------
read_stdin(){ if [[ -t 0 ]]; then echo ""; else cat; fi; }
_append(){ printf '%s\n' "$1" >> "$H/LOG.md"; }
append_log(){  # TYPE TITLE ; body on stdin
  local type="$1" title="$2" body; body="$(read_stdin)"
  local entry; entry="$(printf '\n### %s | %s@%s | %s | %s\n%s\n' "$(ts)" "$(me)" "$(host)" "$type" "$title" "$body")"
  with_lock _append "$entry"
}
cmd_log(){
  [[ $# -ge 2 ]] || die "usage: handoff.sh log TYPE TITLE [-m BODY]  (or body on stdin)"
  local type="${1^^}"; shift; local title="" body="" hasm=0
  while [[ $# -gt 0 ]]; do case "$1" in -m) body="$2"; hasm=1; shift 2;; *) title="${title:+$title }$1"; shift;; esac; done
  if (( hasm )); then printf '%s\n' "$body" | append_log "$type" "$title"; else append_log "$type" "$title"; fi
  heartbeat_if_mine; warn_if_other_lock
  do_commit "log $type: $title"
  echo "ok: log $type$(gitnote)"
}
cmd_checkpoint(){
  local f="CHECKPOINT.md"; [[ "${1:-}" == --personal ]] && f="CHECKPOINT_$(me).md"
  local body; body="$(read_stdin)"
  [[ -n "$body" ]] || die "checkpoint: give the CHECKPOINT body on stdin (see references/file-formats.md)"
  { printf '# CHECKPOINT — work in progress\n_Updated: %s by %s@%s_\n\n' "$(ts)" "$(me)" "$(host)"; printf '%s\n' "$body"; } > "$H/$f.tmp"
  mv -f "$H/$f.tmp" "$H/$f"
  heartbeat_if_mine; [[ "$f" == CHECKPOINT.md ]] && warn_if_other_lock
  do_commit "checkpoint"
  echo "ok: $f$(gitnote)"
}

# compact checkpoint: only the fields you pass change; the rest are kept
CP_KEYS="Status Owner Task Plan Doing Runs Half-edited Next Notes"
cp_get(){ grep -m1 "^$1:" "$2" 2>/dev/null | cut -d: -f2- | sed 's/^ //'; }
cmd_cp(){
  local f="$H/CHECKPOINT.md"; declare -A v; local k
  [[ "${1:-}" == --personal ]] && { f="$H/CHECKPOINT_$(me).md"; shift; }
  for k in $CP_KEYS; do v[$k]="$(cp_get "$k" "$f")"; done
  # an old free-form checkpoint: carry its "Exact next action" over once
  [[ -z "${v[Next]}" ]] && v[Next]="$(section "$f" "Exact next action" 3 | tr '\n' ' ' | sed 's/ *$//')"
  while [[ $# -gt 0 ]]; do case "$1" in
    --status) v[Status]="$2";; --task) v[Task]="$2";; --plan) v[Plan]="$2";; --doing) v[Doing]="$2";;
    --runs) v[Runs]="$2";; --edited) v[Half-edited]="$2";; --next) v[Next]="$2";; --note) v[Notes]="$2";;
    --clear) for k in Plan Doing Runs Half-edited Next Notes; do v[$k]=""; done; shift; continue;;
    *) die "cp: unknown option $1 (use --status --task --plan --doing --runs --edited --next --note --clear)";; esac; shift 2; done
  v[Owner]="$(me)"; [[ -z "${v[Status]}" ]] && v[Status]=IN_PROGRESS
  { printf '# CHECKPOINT — work in progress\n_Updated: %s by %s@%s_\n\n' "$(ts)" "$(me)" "$(host)"
    for k in $CP_KEYS; do printf '%s: %s\n' "$k" "${v[$k]:--}"; done; } > "$f.tmp" && mv -f "$f.tmp" "$f"
  heartbeat_if_mine; [[ "$f" == "$H/CHECKPOINT.md" ]] && warn_if_other_lock
  do_commit "checkpoint"
  echo "ok: checkpoint (${v[Status]}; next: ${v[Next]:0:60})$(gitnote)"
}

# ---- plans -----------------------------------------------------------------------------
plan_file(){ local n="$1"; [[ -f "$H/plans/$n.md" ]] && { echo "$H/plans/$n.md"; return; }
  local m; m="$(ls -1 "$H"/plans/*"$n"*.md 2>/dev/null)"; [[ $(printf '%s' "$m" | grep -c .) -eq 1 ]] && { echo "$m"; return; }
  die "no single plan matching '$n' (have: $(ls "$H/plans" 2>/dev/null | sed 's/\.md$//' | tr '\n' ' '))"; }
plan_progress(){ local d t; d=$(grep -cE '^- \[x\] ' "$1"); t=$(grep -cE '^- \[[ x!~]\] ' "$1"); echo "$d/$t"; }
plan_next(){ grep -m1 -E '^- \[ \] ' "$1" | sed 's/^- \[ \] //' | cut -c1-70; }
cmd_plan(){
  local sub="${1:-list}"; shift || true
  mkdir -p "$H/plans"
  case "$sub" in
    list)
      local f n=0; for f in "$H"/plans/*.md; do [[ -f "$f" ]] || continue; n=1
        printf '%-28s %-9s %-5s next: %s\n' "$(basename "$f" .md)" "$(cp_get Status "$f")" "$(plan_progress "$f")" "$(plan_next "$f")"; done
      (( n )) || echo "no plans yet";;
    show)  # everything except the long rationale, unless --full
      local f; f="$(plan_file "${1:?plan name}")"
      if [[ "${2:-}" == --full ]]; then cat "$f"; else grep -vE '^(Why|Rejected):' "$f"; fi;;
    set)   # plan set NAME STATUS [-m reason]
      local f st="${2:?status: draft|agreed|running|done|failed|abandoned}" msg=""; f="$(plan_file "$1")"
      [[ "${3:-}" == -m ]] && msg="$4"
      sed -i "s/^Status:.*/Status: $st/" "$f"
      printf '%s\n' "${msg:-status -> $st}" | append_log PLAN "$(basename "$f" .md): $st"
      heartbeat_if_mine; do_commit "plan $(basename "$f" .md) -> $st"
      echo "ok: plan $(basename "$f" .md) $st ($(plan_progress "$f"))$(gitnote)";;
    step)  # plan step NAME N done|failed|skip [-m result] [--run ID]
      local f n="${2:?step number}" res="${3:?done|failed|skip}" msg="" run=""; f="$(plan_file "$1")"; shift 3
      while [[ $# -gt 0 ]]; do case "$1" in -m) msg="$2"; shift 2;; --run) run="$2"; shift 2;; *) die "plan step: unknown $1";; esac; done
      local mark=x; [[ "$res" == failed ]] && mark='!'; [[ "$res" == skip ]] && mark='~'
      grep -qE "^- \[[ x!~]\] $n\. " "$f" || die "plan has no step '$n.' (steps are lines like: - [ ] $n. ...)"
      local add=""; [[ -n "$msg" ]] && add=" — $msg"; [[ -n "$run" ]] && add="$add (run $run)"
      local esc; esc="$(printf '%s' "$add" | sed 's/[&/\]/\\&/g')"
      sed -i -E "s/^- \[[ x!~]\] ($n\. .*)$/- [$mark] \1$esc/" "$f"
      printf 'Step %s %s%s\n' "$n" "$res" "$add" | append_log STEP "$(basename "$f" .md) step $n $res"
      [[ "$(cp_get Status "$f")" =~ ^(agreed|draft)$ ]] && sed -i "s/^Status:.*/Status: running/" "$f"
      heartbeat_if_mine; do_commit "plan $(basename "$f" .md) step $n $res"
      local nx; nx="$(plan_next "$f")"
      echo "ok: step $n $res · $(plan_progress "$f") done · next: ${nx:-none (all steps closed: plan set $(basename "$f" .md) done)}$(gitnote)";;
    amend) # plan amend NAME -m text
      local f; f="$(plan_file "$1")"; [[ "${2:-}" == -m && -n "${3:-}" ]] || die "usage: plan amend NAME -m \"what changed and why\""
      grep -q '^## Amendments' "$f" || printf '\n## Amendments\n' >> "$f"
      local k; k=$(( $(grep -cE '^- A[0-9]+ ' "$f") + 1 ))
      printf -- '- A%s %s %s: %s\n' "$k" "$(date +%F)" "$(me)" "$3" >> "$f"
      printf '%s\n' "$3" | append_log DECISION "$(basename "$f" .md) amendment A$k"
      heartbeat_if_mine; do_commit "plan $(basename "$f" .md) amendment A$k"
      echo "ok: amendment A$k$(gitnote)";;
    *) die "plan: list | show NAME [--full] | set NAME STATUS [-m why] | step NAME N done|failed|skip [-m result] [--run ID] | amend NAME -m text";;
  esac
}

# ---- runs ----------------------------------------------------------------------------
cmd_run(){
  local name="" fg=0 cwd="$PWD" note=""
  while [[ $# -gt 0 ]]; do case "$1" in
    --name) name="$2"; shift 2;; --foreground) fg=1; shift;; --cwd) cwd="$2"; shift 2;;
    --note) note="$2"; shift 2;; --) shift; break;; *) die "run: unknown arg $1 (put the command after --)";; esac; done
  [[ -n "$name" ]] || die "run needs --name NAME"
  [[ $# -gt 0 ]] || die "run needs a command after --"
  name="$(echo "$name" | tr -c 'A-Za-z0-9._-' '_' | sed 's/_*$//')"
  cwd="$(cd "$cwd" && pwd -P)" || die "bad --cwd"
  warn_if_other_lock
  local id; id="$(ts_compact)_${name}_$(me)"
  [[ -e "$H/runs/$id" ]] && id="${id}_$RANDOM"
  local d="$H/runs/$id"
  mkdir -p "$d" || die "cannot create $d"
  { echo "#!/usr/bin/env bash"; printf 'cd %q || exit 97\n' "$cwd"; printf '%q ' "$@"; echo; } > "$d/cmd.sh"
  local commit="-"; has_git && commit="$(g rev-parse --short HEAD 2>/dev/null || echo -)"
  local dirty="no"; has_git && ! g diff --quiet -- . ':(exclude).handoff' 2>/dev/null && dirty="yes (uncommitted code changes!)"
  cat > "$d/meta" <<EOF
run_id=$id
name=$name
user=$(me)
unix_user=$(id -un)
host=$(host)
cwd=$cwd
git_commit=$commit
git_dirty=$dirty
slurm_job_id=${SLURM_JOB_ID:-}
started=$(epoch)
started_h=$(ts)
note=$note
command=$(printf '%q ' "$@")
EOF
  echo RUNNING > "$d/status"
  printf 'Run id: %s\nCommand: %s\ncwd: %s | git: %s | note: %s\n' "$id" "$(printf '%q ' "$@")" "$cwd" "$commit" "$note" | append_log RUN "started $name"
  heartbeat_if_mine
  if (( fg )); then
    echo "RUN: $id (foreground)"
    "$SELF" --root "$ROOT" _exec "$d"; return $?
  fi
  setsid nohup "$SELF" --root "$ROOT" _exec "$d" >/dev/null 2>&1 < /dev/null &
  local i; for i in 1 2 3 4 5 6 7 8 9 10; do [[ -s "$d/pid" ]] && break; sleep 0.2; done
  echo "ok: run $id started (detached, pid $(cat "$d/pid" 2>/dev/null || echo ?); check: runs / show $id)"
  [[ "$dirty" != no ]] && warn "code has uncommitted changes; commit first so this run is reproducible"
  return 0
}
_runs_append(){ printf '%s\n' "$1" >> "$H/RUNS.tsv"; }
cmd__exec(){  # internal: executes a run directory
  local d="$1"; echo $$ > "$d/pid"; echo "$(host)" > "$d/pid_host"
  local start; start=$(epoch); local killed=0 child rc
  trap 'killed=1; [[ -n "${child:-}" ]] && kill -TERM "$child" 2>/dev/null' TERM INT
  bash "$d/cmd.sh" > "$d/stdout.log" 2> "$d/stderr.log" & child=$!
  echo "$child" > "$d/child_pid"
  while :; do wait "$child"; rc=$?; kill -0 "$child" 2>/dev/null || break; done
  local end; end=$(epoch); local st=DONE
  (( rc != 0 )) && st=FAILED; (( killed )) && st=KILLED
  echo "$rc" > "$d/exit_code"; echo "$st" > "$d/status"
  { echo "ended=$end"; echo "ended_h=$(ts)"; echo "duration_s=$((end-start))"; echo "exit_code=$rc"; echo "status=$st"; } >> "$d/meta"
  local name user cwd cmd
  name="$(grep -m1 '^name=' "$d/meta" | cut -d= -f2-)"; user="$(grep -m1 '^user=' "$d/meta" | cut -d= -f2-)"
  cwd="$(grep -m1 '^cwd=' "$d/meta" | cut -d= -f2-)"; cmd="$(grep -m1 '^command=' "$d/meta" | cut -d= -f2-)"
  local line; line="$(printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s' "$(basename "$d")" "$user" "$(host)" "$name" \
     "$(date -d @"$start" '+%F %T')" "$(date -d @"$end" '+%F %T')" "$st" "$rc" "$((end-start))" "$cwd" "$cmd")"
  with_lock _runs_append "$line"
  printf 'Run id: %s | status %s | exit %s | %ss | stderr tail: %s\n' "$(basename "$d")" "$st" "$rc" "$((end-start))" \
    "$(tail -n 3 "$d/stderr.log" 2>/dev/null | tr '\n' ' ' | cut -c1-300)" | append_log RUN "finished $name -> $st"
  return "$rc"
}
run_live_status(){  # $1 run dir -> prints status (verifies RUNNING)
  local d="$1" st; st="$(cat "$d/status" 2>/dev/null || echo UNKNOWN)"
  if [[ "$st" == RUNNING ]]; then
    local pid h; pid="$(cat "$d/pid" 2>/dev/null)"; h="$(cat "$d/pid_host" 2>/dev/null)"
    if [[ -z "$pid" ]]; then echo "STARTING?"; return; fi
    if [[ "$h" != "$(host)" ]]; then echo "RUNNING(on $h: cannot verify from here)"; return; fi
    local pst; pst="$(ps -o stat= -p "$pid" 2>/dev/null | tr -d ' ')"
    if [[ -n "$pst" && "$pst" != Z* ]]; then echo RUNNING
    elif ps -eo pgid=,stat= 2>/dev/null | awk -v g="$pid" '$1==g && $2 !~ /^Z/ {f=1} END{exit !f}'; then echo "ORPHANED(wrapper gone, process group $pid still running; do not relaunch)"
    else echo "DIED(no exit recorded: killed -9 / reboot / OOM?)"; fi
  else echo "$st"; fi
}
cmd_runs(){
  local all=0; [[ "${1:-}" == --all ]] && all=1
  local dirs; mapfile -t dirs < <(ls -1d "$H"/runs/*/ 2>/dev/null | sort)
  (( ${#dirs[@]} )) || { echo "RUNS: none yet"; return; }
  if (( ! all && ${#dirs[@]} > 15 )); then dirs=("${dirs[@]:${#dirs[@]}-15}"); fi
  printf '%-44s %-10s %-40s %-9s %s\n' RUN_ID USER STATUS ELAPSED NOTE
  local d; for d in "${dirs[@]}"; do
    d="${d%/}"; local id st u s e el note
    id="$(basename "$d")"; st="$(run_live_status "$d")"
    u="$(grep -m1 '^user=' "$d/meta" | cut -d= -f2-)"; s="$(grep -m1 '^started=' "$d/meta" | cut -d= -f2-)"
    e="$(grep -m1 '^ended=' "$d/meta" | cut -d= -f2-)"; note="$(grep -m1 '^note=' "$d/meta" | cut -d= -f2-)"
    el=$(human_age $(( ${e:-$(epoch)} - ${s:-$(epoch)} )))
    printf '%-44s %-10s %-40s %-9s %s\n' "$id" "$u" "$st" "$el" "$note"
  done
}
cmd_show(){
  local id="${1:-}"; [[ -n "$id" ]] || die "usage: show RUN_ID"
  local d="$H/runs/$id"; [[ -d "$d" ]] || d="$(ls -1d "$H"/runs/*"$id"*/ 2>/dev/null | tail -1)"; d="${d%/}"
  [[ -d "$d" ]] || die "no run matching $id"
  local n="${2:-12}"
  echo "== $(basename "$d") · $(run_live_status "$d")"
  grep -E '^(command|cwd|git_commit|git_dirty|started_h|ended_h|duration_s|exit_code|note)=' "$d/meta"
  local e; e="$(grep -inE 'error|exception|traceback|fatal|killed|memory|cannot|no such' "$d/stderr.log" 2>/dev/null | tail -n 6)"
  [[ -n "$e" ]] && { echo "== error-like lines in stderr"; echo "$e"; }
  echo "== stderr (last $n)"; tail -n "$n" "$d/stderr.log" 2>/dev/null
  echo "== stdout (last $n)"; tail -n "$n" "$d/stdout.log" 2>/dev/null
}
cmd_stop(){
  local id="" reason=""
  while [[ $# -gt 0 ]]; do case "$1" in --reason) reason="$2"; shift 2;; *) id="$1"; shift;; esac; done
  [[ -n "$id" && -n "$reason" ]] || die "usage: stop RUN_ID --reason TEXT"
  local d="$H/runs/$id"; [[ -d "$d" ]] || die "no run $id"
  local pid; pid="$(cat "$d/pid" 2>/dev/null)"; [[ -n "$pid" ]] || die "no pid recorded"
  [[ "$(cat "$d/pid_host")" == "$(host)" ]] || die "run is on another host ($(cat "$d/pid_host")); stop it there"
  if kill -TERM -- "-$pid" 2>/dev/null || kill -TERM "$pid" 2>/dev/null; then
    printf 'Run: %s\nReason: %s\n' "$id" "$reason" | append_log STOP "stopped run $id"
    do_commit "stop run $id"; echo "ok: SIGTERM sent to $id$(gitnote)"
  else die "could not signal pid $pid (owned by another Unix user? ask them, or use sudo)"; fi
}

# ---- manifest ------------------------------------------------------------------------
_manifest_append(){ printf '%s\n' "$1" >> "$H/DATA_MANIFEST.tsv"; }
cmd_manifest(){
  [[ $# -ge 2 ]] || die "usage: manifest PATH ROLE [DESCRIPTION]   ROLE: raw|reference|intermediate|final|obsolete"
  local p="$1" role="$2"; shift 2; local desc="$*"
  [[ -e "$p" ]] || die "not found: $p"
  local abs; abs="$(readlink -f "$p")"
  local size md5="skipped(>${MD5_MAX_MB}MB)"
  if [[ -d "$abs" ]]; then
    size="$(du -sb "$abs" 2>/dev/null | cut -f1)"
    md5="dir:$(find "$abs" -type f -printf '%P %s\n' 2>/dev/null | sort | md5sum | cut -c1-32)(names+sizes)"
  else
    size="$(stat -c %s "$abs")"
    (( size <= MD5_MAX_MB*1024*1024 )) && md5="$(md5sum "$abs" | cut -c1-32)"
  fi
  local line; line="$(printf '%s\t%s\t%s\t%s\t%s\t%s\t%s' "$abs" "$role" "$size" "$md5" "$(me)" "$(ts)" "$desc")"
  with_lock _manifest_append "$line"
  echo "MANIFEST: $abs  role=$role size=$size md5=$md5"
  heartbeat_if_mine
}

# ---- commit / end -------------------------------------------------------------------
cmd_commit(){
  [[ $# -ge 1 ]] || die "usage: commit MSG [--add PATH...]"
  local msg="$1"; shift; local adds=()
  if [[ "${1:-}" == --add ]]; then shift; adds=("$@"); fi
  has_git || { warn "no git repository at $ROOT"; return 0; }
  CODE=1 do_commit "$msg" "${adds[@]}"
  echo "ok: commit${COMMIT_SHORT:+ $COMMIT_SHORT}${COMMIT_SHORT:- (nothing to commit)}"
  local u; u="$(g status --porcelain 2>/dev/null | head -20)"
  [[ -n "$u" && "$(git_mode)" != "handoff-owned" ]] && { echo "Still uncommitted / untracked (add explicitly with --add if they are code):"; echo "$u"; }
  return 0
}
cmd_end(){
  local paused=0; [[ "${1:-}" == --paused ]] && paused=1
  local body=""; [[ "${1:-}" != -m && "${2:-}" != -m ]] && body="$(read_stdin)"
  local t="session ended"; (( paused )) && t="session PAUSED mid-task (resume from CHECKPOINT.md)"
  [[ "${1:-}" == -m ]] && body="$2"; [[ "${2:-}" == -m ]] && body="$3"
  printf '%s\n' "${body:-(no summary given)}" | append_log HANDOFF "$t"
  do_commit "handoff: $t"
  local l=""; [[ "$(lock_state)" == mine ]] && { rm -f "$H/LOCK"; l=" · lock released"; }
  echo "ok: handoff logged$l$(gitnote)"
}

# ---- status ---------------------------------------------------------------------------
section(){ awk -v h="$2" 'BEGIN{p=0} /^## /{p=($0 ~ "^## "h)?1:0; next} p' "$1" 2>/dev/null | sed '/^[[:space:]]*$/d' | head -n "${3:-12}"; }
cmd_status(){
  echo "================ PROJECT: $PROJECT_NAME   ($ROOT)"
  echo "You: $(me)@$(host)   now: $(ts)"
  echo "---------------- LOCK"
  case "$(lock_state)" in
    free) echo "free";;
    mine) echo "held by YOU since $(date -d @"$(lock_get since)" '+%F %R' 2>/dev/null) (task: $(lock_get task))";;
    active|stale) echo "$(lock_state | tr a-z A-Z): held by $(lock_get user)@$(lock_get host), last heartbeat $(human_age $(( $(epoch)-$(lock_get heartbeat) ))) ago, task: $(lock_get task)";;
  esac
  echo "---------------- CHECKPOINT ($(sed -n '2p' "$H/CHECKPOINT.md" 2>/dev/null | tr -d '_'))"
  grep -E '^(Status|Owner|Task):' "$H/CHECKPOINT.md" 2>/dev/null
  echo "Exact next action:"; section "$H/CHECKPOINT.md" "Exact next action" 6 | sed 's/^/   /'
  echo "Open sub-steps:"; grep -E '^\s*- \[ \]' "$H/CHECKPOINT.md" 2>/dev/null | head -8 | sed 's/^/   /'
  local pc; for pc in "$H"/CHECKPOINT_*.md; do [[ -f "$pc" ]] || continue
    echo "  parallel checkpoint $(basename "$pc"): $(grep -m1 '^Status:' "$pc") | $(grep -m1 '^Task:' "$pc") ($(sed -n '2p' "$pc" | tr -d '_'))"; done
  echo "---------------- RUNS"
  local d n_running=0 lines=() rdirs=()
  mapfile -t rdirs < <(ls -1d "$H"/runs/*/ 2>/dev/null | sort | tail -40)
  for d in "${rdirs[@]}"; do
    d="${d%/}"; local st; st="$(run_live_status "$d")"
    local s; s="$(grep -m1 '^started=' "$d/meta" | cut -d= -f2-)"
    if [[ "$st" == RUNNING* || "$st" == DIED* || "$st" == STARTING* ]] || (( $(epoch) - ${s:-0} < 172800 )); then
      lines+=("   $(basename "$d")  ->  $st"); [[ "$st" == RUNNING* ]] && n_running=$((n_running+1))
    fi
  done
  echo "running now: $n_running   (showing active + last 48h)"; printf '%s\n' "${lines[@]:-   (none)}"
  echo "---------------- GIT"
  if has_git; then
    echo "branch: $(g rev-parse --abbrev-ref HEAD 2>/dev/null)   last commit: $(g log -1 --format='%h %an %ar: %s' 2>/dev/null)"
    local dirty; dirty="$(g status --porcelain --untracked-files=no -- . ':(exclude).handoff' 2>/dev/null)"
    if [[ -n "$dirty" ]]; then echo "UNCOMMITTED changes to tracked files (possible half-finished edits):"; echo "$dirty" | head -15 | sed 's/^/   /'
    else echo "working tree clean (tracked files)"; fi
  else echo "no git repository"; fi
  echo "---------------- LAST LOG ENTRIES"
  grep '^### ' "$H/LOG.md" 2>/dev/null | tail -6 | sed 's/^### /   /'
  local imp; for imp in "$H"/imports/*/; do [[ -d "$imp" ]] || continue
    [[ -f "$imp/RECONCILED" ]] || echo "IMPORT NOT YET RECONCILED: .handoff/imports/$(basename "$imp")  (see references/outside-work.md)"; done
  echo "---------------- TODO (Now)"
  section "$H/TODO.md" "Now" 8 | sed 's/^/   /'
  if [[ -f "$H/inventory/files.tsv" ]]; then
    local age=$(( $(epoch) - $(stat -c %Y "$H/inventory/files.tsv") ))
    echo "---------------- last file scan: $(human_age $age) ago  (run 'handoff.sh rescan' to detect unlogged changes)"
  fi
}

# ---- brief: the ONE call to make at the start of a session -----------------------------------
# Prints only what changed since YOUR last brief (per-user marker in .handoff/.seen/).
first_lines(){ section "$1" "$2" "${3:-2}" | cut -c1-150 | sed 's/^/  /'; }
cmd_brief(){
  local noscan=0; [[ "${1:-}" == --no-scan ]] && noscan=1
  mkdir -p "$H/.seen"; local sf="$H/.seen/$(me)" last_e=0 last_l=0
  [[ -f "$sf" ]] && read -r last_e last_l < "$sf"
  local now; now=$(epoch); local loglines; loglines=$(wc -l < "$H/LOG.md")
  local since="never"; (( last_e > 0 )) && since="$(human_age $((now-last_e))) ago"
  echo "== $PROJECT_NAME · you: $(me) · your last brief: $since"
  case "$(lock_state)" in
    free) echo "LOCK: free";; mine) echo "LOCK: yours";;
    *) echo "LOCK: $(lock_state | tr a-z A-Z) — $(lock_get user), heartbeat $(human_age $(( now-$(lock_get heartbeat) ))) ago, task: $(lock_get task)";;
  esac
  echo "STATE (stage / next):"; first_lines "$H/STATE.md" "Current stage" 2; first_lines "$H/STATE.md" "Next step" 2
  local c="$H/CHECKPOINT.md" k
  echo "CHECKPOINT ($(sed -n '2p' "$c" 2>/dev/null | tr -d '_' | sed 's/^Updated: //')):"
  if grep -q '^Doing:' "$c" 2>/dev/null; then
    for k in Status Task Plan Doing Runs Half-edited Next; do local v; v="$(cp_get "$k" "$c")"; [[ -n "$v" && "$v" != - ]] && echo "  $k: ${v:0:160}"; done
  else grep -E '^(Status|Owner|Task):' "$c" 2>/dev/null | sed 's/^/  /'; first_lines "$c" "Exact next action" 3; fi
  local pc; for pc in "$H"/CHECKPOINT_*.md; do [[ -f "$pc" ]] && echo "  parallel: $(basename "$pc" .md | sed 's/CHECKPOINT_//') — $(cp_get Task "$pc") · next: $(cp_get Next "$pc" | cut -c1-80)"; done
  local f np=0; for f in "$H"/plans/*.md; do [[ -f "$f" ]] || continue
    local st; st="$(cp_get Status "$f")"; [[ "$st" =~ ^(done|abandoned)$ ]] && continue
    (( np++ == 0 )) && echo "PLANS (open):"; echo "  $(basename "$f" .md): $st $(plan_progress "$f") · next: $(plan_next "$f")"; done
  local d rdirs=() out=() nok=0 lastok=""; mapfile -t rdirs < <(ls -1d "$H"/runs/*/ 2>/dev/null | sort | tail -60)
  for d in "${rdirs[@]}"; do d="${d%/}"; local st e; st="$(run_live_status "$d")"; e="$(grep -m1 '^ended=' "$d/meta" | cut -d= -f2-)"
    if [[ "$st" == RUNNING* || "$st" == STARTING* || "$st" == ORPHANED* ]]; then out+=("  $(basename "$d"): $st ($(human_age $(( now-$(grep -m1 '^started=' "$d/meta" | cut -d= -f2-) ))))")
    elif [[ "$st" == DONE ]] && (( ${e:-0} > last_e )); then nok=$((nok+1)); lastok="$(basename "$d")"
    elif [[ "$st" == DIED* ]] || (( ${e:-0} > last_e )); then out+=("  $(basename "$d"): ${st%%(*}$( [[ -s "$d/exit_code" ]] && echo " exit $(cat "$d/exit_code")")"); fi; done
  (( nok )) && out+=("  $nok finished OK since your last brief (latest: $lastok)")
  if (( ${#out[@]} )); then echo "RUNS:"; printf '%s\n' "${out[@]}" | tail -10; fi
  if has_git; then local dirty; dirty="$(g status --porcelain --untracked-files=no -- . ':(exclude).handoff' 2>/dev/null)"
    [[ -n "$dirty" ]] && { echo "UNCOMMITTED code (half-done edits?):"; echo "$dirty" | head -8 | sed 's/^/  /'; }; fi
  if (( loglines > last_l )); then
    local news; news="$(tail -n +$((last_l+1)) "$H/LOG.md" | grep '^### ' | grep -v "| $(me)@" | grep -vE '\| RUN \|' | sed 's/^### //')"
    local nn; nn=$(printf '%s' "$news" | grep -c .)
    (( nn )) && { echo "NEW in LOG by others since your last brief ($nn):"; echo "$news" | tail -8 | sed 's/^/  /'; }
  fi
  if (( ! noscan )) && [[ "${SCAN_ON_BRIEF:-1}" == 1 ]]; then cmd_rescan --line; fi
  local imp; for imp in "$H"/imports/*/; do [[ -d "$imp" && ! -f "$imp/RECONCILED" ]] && echo "IMPORT not reconciled: $(basename "$imp")"; done
  local td; td="$(section "$H/TODO.md" "Now" 4 | cut -c1-100)"; [[ -n "$td" ]] && { echo "TODO now:"; echo "$td" | sed 's/^/  /'; }
  echo "$now $loglines" > "$sf"
}

# ---- adoption helpers: compact overview + IO lines of a script -------------------------------
cmd_summary(){
  local inv="$H/inventory"
  echo "== folders (largest 20): dir · files · MB · newest"; tail -n +2 "$inv/dir_summary.tsv" | sort -t$'\t' -k3,3nr | head -20 | tr '\t' ' ' | sed 's/^/  /'
  local ns; ns=$(( $(wc -l < "$inv/scripts.tsv") - 1 ))
  echo "== code files, oldest first ($ns; showing up to 60): path · lines · modified"; tail -n +2 "$inv/scripts.tsv" | head -60 | cut -f1-3 | tr '\t' ' ' | sed 's/^/  /'
  echo "== paths each script mentions (up to 8 per script)"
  tail -n +2 "$inv/io_hints.tsv" | awk -F'\t' '{c[$1]++; if(c[$1]<=8) l[$1]=l[$1] (c[$1]>1?", ":"") $3} END{for(k in l) print "  " k ": " l[k]}' | sort | head -60
  echo "== data/results by folder: files · first → last change"
  tail -n +2 "$inv/data_timeline.tsv" | awk -F'\t' '{n=split($4,a,"/"); d=(n>2)?a[1]"/"a[2]:(n==2?a[1]:"."); c[d]++; if(!(d in f))f[d]=$1; l[d]=$1} END{for(d in c) print "  " d ": " c[d] " · " f[d] " → " l[d]}' | sort | head -30
  echo "== environment"; grep -vE '^#|^$' "$inv/envs.txt" | head -14 | cut -c1-140 | sed 's/^/  /'
  echo "== git"; head -2 "$inv/git.txt" | sed 's/^/  /'; sed -n '/## last 40 commits/,/^$/p' "$inv/git.txt" | sed -n '2,9p' | sed 's/^/  /'
  echo "== running jobs touching the project"; grep -vE '^#|^\(none\)' "$inv/jobs.txt" | head -10 | sed 's/^/  /'
  echo "== permissions: $(grep -m1 '^count:' "$inv/perms.txt" 2>/dev/null) not group-writable"
  local imp; for imp in "$H"/imports/*/; do [[ -d "$imp" ]] && echo "== import: $(basename "$imp") ($(find "$imp" -type f | wc -l) files)"; done
  return 0
}
cmd_io(){  # read/write/load/save lines of one or more scripts — read these instead of whole scripts
  local f; for f in "$@"; do [[ -f "$f" ]] || f="$ROOT/$f"; [[ -f "$f" ]] || { warn "no file $f"; continue; }
    echo "== ${f#$ROOT/}"
    grep -nE '(^|[^A-Za-z_])(library|require|import|from|read[A-Za-z_.]*|Read[A-Za-z0-9_]*|load[A-Za-z_]*|Load[A-Za-z0-9_]*|fread|open|save[A-Za-z_]*|write[A-Za-z_.]*|Write[A-Za-z0-9_]*|to_csv|to_parquet|savefig|ggsave|pdf|png|set\.seed|seed|argparse|commandArgs|sys\.argv)[[:space:]]*\(|^import |^from ' "$f" | cut -c1-160 | head -40
  done
}

# ---- inventory / adopt -------------------------------------------------------------
build_prune(){
  PRUNE=(); local ex first=1
  for ex in $SCAN_EXCLUDE; do
    (( first )) || PRUNE+=(-o); first=0
    if [[ "$ex" == */* ]]; then PRUNE+=(-path "$ROOT/$ex"); else PRUNE+=(-name "$ex"); fi
  done
}
CODE_RE='\.(R|r|Rmd|qmd|py|ipynb|sh|bash|smk|nf|wdl|pl|jl|m|sql|do|sps)$|(^|/)(Snakefile|Makefile|nextflow\.config|Dockerfile)$'
scan_files(){  # writes inventory/files.tsv (path size mtime epoch owner)
  local inv="$H/inventory"; build_prune
  [[ -f "$inv/files.tsv" ]] && mv -f "$inv/files.tsv" "$inv/files.prev.tsv"
  { printf 'path\tsize\tmtime\tepoch\towner\n'
    find "$ROOT" \( "${PRUNE[@]}" \) -prune -o -type f -printf '%P\t%s\t%TY-%Tm-%Td %TH:%TM\t%Ts\t%u\n' 2>/dev/null | sort -t$'\t' -k1,1
  } > "$inv/files.tsv"
}
scan_derived(){
  local inv="$H/inventory"
  # per-directory summary (2 levels)
  awk -F'\t' 'NR>1{n=split($1,a,"/"); d=(n==1)?".":(n==2?a[1]:a[1]"/"a[2]); c[d]++; s[d]+=$2; if($4>m[d]){m[d]=$4}}
    END{for(d in c) printf "%s\t%d\t%.1f\t%d\n", d, c[d], s[d]/1048576, m[d]}' "$inv/files.tsv" 2>/dev/null \
    | sort | while IFS=$'\t' read -r dd cc ss mm; do printf '%s\t%s\t%s\t%s\n' "$dd" "$cc" "$ss" "$(date -d @"${mm%.*}" '+%F %R' 2>/dev/null)"; done > "$inv/dir_summary.tmp" || true
  { printf 'dir\tfiles\tsize_MB\tnewest_change\n'; cat "$inv/dir_summary.tmp"; } > "$inv/dir_summary.tsv"; rm -f "$inv/dir_summary.tmp"
  # code files, oldest -> newest
  { printf 'path\tlines\tmtime\towner\n'
    awk -F'\t' -v re="$CODE_RE" 'NR>1 && $1 ~ re {print $4"\t"$1"\t"$3"\t"$5}' "$inv/files.tsv" | sort -n | \
    while IFS=$'\t' read -r _ p mt ow; do printf '%s\t%s\t%s\t%s\n' "$p" "$(wc -l < "$ROOT/$p" 2>/dev/null || echo ?)" "$mt" "$ow"; done
  } > "$inv/scripts.tsv"
  # data/output files, oldest -> newest (production timeline)
  { printf 'mtime\tsize_MB\towner\tpath\n'
    awk -F'\t' -v re="$CODE_RE" 'NR>1 && $1 !~ re {printf "%s\t%s\t%.2f\t%s\t%s\n", $4, $3, $2/1048576, $5, $1}' "$inv/files.tsv" | sort -n | cut -f2-
  } > "$inv/data_timeline.tsv"
  # file paths mentioned inside code (hints for inputs/outputs of each script)
  { printf 'script\tline\tmentioned_path\n'
    tail -n +2 "$inv/scripts.tsv" | cut -f1 | while IFS= read -r p; do
      [[ "$p" == *.ipynb ]] && continue
      grep -noE "[\"'][^\"' ]+\.(rds|RDS|rda|RData|qs|h5ad|h5|hdf5|loom|csv|tsv|txt|mtx|gz|bam|bed|gtf|gff|fa|fasta|fastq|xlsx|xls|json|parquet|feather|pdf|png|svg|tif|tiff|jpg|zarr|pkl|pickle|npy|npz)[\"']" "$ROOT/$p" 2>/dev/null \
        | sed -E "s/^([0-9]+):[\"'](.*)[\"']$/\1\t\2/" | sed "s|^|$p\t|"
    done
  } > "$inv/io_hints.tsv"
}
scan_env(){
  local inv="$H/inventory"
  {
    echo "# Environment scan $(ts) by $(me)@$(host)"
    for t in R Rscript python3 python conda mamba snakemake nextflow java samtools cellranger spaceranger docker singularity apptainer; do
      if command -v "$t" >/dev/null 2>&1; then
        local v; v="$(timeout 10 "$t" --version 2>&1 | grep -v '^Picked up' | head -1 | cut -c1-120)"; echo "$t: $(command -v "$t") | $v"
      fi
    done
    if command -v conda >/dev/null 2>&1; then echo; echo "## conda envs"; timeout 30 conda env list 2>/dev/null; fi
    if command -v module >/dev/null 2>&1; then echo; echo "## loaded modules"; module list 2>&1 | head -20; fi
    echo; echo "## environment/lock files found in project"
    find "$ROOT" -maxdepth 4 \( -name environment.yml -o -name 'environment*.yaml' -o -name renv.lock -o -name 'requirements*.txt' \
      -o -name pyproject.toml -o -name DESCRIPTION -o -name 'sessionInfo*' -o -name Snakefile -o -name nextflow.config -o -name Dockerfile -o -name '*.def' \) \
      -not -path '*/.handoff/*' -not -path '*/renv/library/*' 2>/dev/null | sed "s|^$ROOT/||"
  } > "$inv/envs.txt"
}
scan_git(){
  local inv="$H/inventory"
  { if has_git; then
      echo "repo top: $(g rev-parse --show-toplevel)"; echo "branch: $(g rev-parse --abbrev-ref HEAD 2>/dev/null)"
      echo; echo "## last 40 commits"; g log -40 --format='%h %ad %an: %s' --date=short 2>/dev/null
      echo; echo "## status (first 200 lines)"; g status --short 2>/dev/null | head -200
    else echo "no git repository"; fi; } > "$inv/git.txt"
}
scan_jobs(){
  local inv="$H/inventory"
  { echo "# Jobs/processes touching this project, $(ts), seen from $(me)@$(host)"
    echo "## processes whose command line mentions the project path"
    ps -eo user,pid,etime,args 2>/dev/null | grep -F -- "$ROOT" | grep -v -e 'grep -F' -e 'handoff.sh' || echo "(none)"
    echo "## your own processes running inside the project directory"
    local p; for p in $(pgrep -u "$(id -u)" 2>/dev/null); do
      local c; c="$(readlink "/proc/$p/cwd" 2>/dev/null)"
      [[ "$c" == "$ROOT"* ]] && ps -o user=,pid=,etime=,args= -p "$p" 2>/dev/null
    done
    if command -v squeue >/dev/null 2>&1; then echo "## SLURM jobs with work dir in project"; squeue -h -o '%i|%u|%T|%M|%j|%Z' 2>/dev/null | grep -F -- "$ROOT" || echo "(none)"; fi
    if command -v tmux >/dev/null 2>&1; then echo "## your tmux sessions"; tmux ls 2>/dev/null || echo "(none)"; fi
    if command -v screen >/dev/null 2>&1; then echo "## your screen sessions"; screen -ls 2>/dev/null | grep -E '^\s' || echo "(none)"; fi
  } > "$inv/jobs.txt"
}
scan_history(){  # opt-in: only the CURRENT user's own shell/R/python history, lines mentioning the project
  local inv="$H/inventory" out="$H/inventory/history_$(me).txt" key; key="$(basename "$ROOT")"
  { echo "# Commands from $(me)'s own history files that mention '$key' or the project path."
    echo "# Lines that look like they contain secrets were dropped. Order = file order (no timestamps unless HISTTIMEFORMAT was set)."
    local f; for f in "$HOME/.bash_history" "$HOME/.zsh_history" "$HOME/.local/share/fish/fish_history" "$HOME/.python_history" "$ROOT/.Rhistory" "$HOME/.Rhistory"; do
      [[ -r "$f" ]] || continue; echo; echo "## $f"
      # keep lines that mention the project, plus the commands typed after "cd" into it (until cd elsewhere)
      awk -v root="$ROOT" -v key="$key" '
        { line=$0; sub(/^: [0-9]+:[0-9]+;/, "", line) }               # zsh extended-history prefix
        index(line, root) || index(line, key) { inproj=1; print line; next }
        line ~ /^[[:space:]]*cd([[:space:]]|$)/ { inproj=0; next }
        inproj { print line }' "$f" 2>/dev/null \
        | grep -aviE 'pass(word|wd)?|token|secret|api[_-]?key|authorization|bearer|ssh-|BEGIN .*PRIVATE' | tail -n 400
    done; } > "$out"
  echo "history: wrote $out (review it before relying on it)"
}
cmd_rescan(){
  local q=0 line=0; [[ "${1:-}" == --quiet ]] && q=1; [[ "${1:-}" == --line ]] && { q=1; line=1; }
  scan_files; scan_derived; scan_git; scan_jobs
  local inv="$H/inventory" rep="$H/inventory/drift_latest.txt"
  if [[ -f "$inv/files.prev.tsv" ]]; then
    local prevt; prevt="$(date -d @"$(stat -c %Y "$inv/files.prev.tsv")" '+%F %R')"
    awk -F'\t' -v rep="$rep" -v since="$prevt" '
      FNR==1{next}
      NR==FNR{old[$1]=$2"\t"$4; next}
      { cur[$1]=1; if(!($1 in old)) add[++na]=$1"\t"$2"\t"$3"\t"$5; else if(old[$1]!=$2"\t"$4) mod[++nm]=$1"\t"$2"\t"$3"\t"$5 }
      END{ for(p in old) if(!(p in cur)) del[++nd]=p
        print "# Drift since previous scan (" since ")" > rep
        print "## ADDED (" na+0 ")  path size mtime owner" >> rep;   for(i=1;i<=na;i++) print add[i] >> rep
        print "## MODIFIED (" nm+0 ")" >> rep; for(i=1;i<=nm;i++) print mod[i] >> rep
        print "## DELETED (" nd+0 ")" >> rep;  for(i=1;i<=nd;i++) print del[i] >> rep
        printf "FILES changed since last scan (%s): %d added, %d modified, %d deleted\n", since, na, nm, nd }' \
      "$inv/files.prev.tsv" "$inv/files.tsv" | { if (( line )); then awk '/ 0 added, 0 modified, 0 deleted/{exit} {print; exit}'; else cat; fi; }
    if (( line )); then grep -vE '^#' "$rep" | grep -v '^## ' | head -5 | cut -f1 | sed 's/^/  /'; else echo "  details: $rep"; fi
    cp -f "$rep" "$inv/drift_$(ts_compact).txt"
    ls -1t "$inv"/drift_2*.txt 2>/dev/null | tail -n +21 | xargs -r rm -f   # keep last 20 reports
  else echo "RESCAN: first scan, nothing to compare"; fi
  (( q )) || echo "inventory refreshed in $inv"
}

write_if_absent(){ [[ -e "$1" ]] && return 0; cat > "$1"; echo "  created $(basename "$1")"; }
make_templates(){
  local P="$PROJECT_NAME"
  write_if_absent "$H/config.env" <<EOF
# project-handoff settings (shell syntax). Both users share this file.
PROJECT_NAME="$P"
STALE_LOCK_HOURS=3          # a lock with no heartbeat for this long may be taken over
MD5_MAX_MB=200              # files bigger than this get size+mtime instead of md5
EXTRA_PATHS=""              # space-separated folders OUTSIDE the project that it depends on (references, raw data)
SCAN_EXCLUDE="$SCAN_EXCLUDE"
EOF
  load_config
  write_if_absent "$H/README.md" <<'EOF'
# .handoff — shared working memory for this project

This folder lets two people (and their Claude sessions) continue each other's work.
Read in this order: STATE.md -> CHECKPOINT.md -> TODO.md -> last entries of LOG.md.

| File | What it is | How it changes |
|---|---|---|
| STATE.md | 1-page snapshot of where the project stands | rewritten at every handoff |
| CHECKPOINT.md | write-ahead note of the task in progress + exact next action | rewritten before/after every sub-step |
| LOG.md | chronological record of every action, run, decision, failure | append only |
| PIPELINES.md | every script/pipeline: purpose, inputs, outputs, status | edited |
| DATA_MANIFEST.tsv | key data files: role, size, md5, who, when | append (handoff.sh manifest) |
| DECISIONS.md | why things were done this way | append |
| plans/ | one file per agreed pipeline: why, steps, parameters, checks, amendments | handoff.sh plan … |
| TODO.md | Now / Next / Blocked / Done | edited |
| BASELINE.md | reconstruction of work done BEFORE handoff was adopted | written once, corrected later |
| RUNS.tsv + runs/ | every job started with handoff.sh run: command, logs, exit status | automatic |
| LOCK | who is working right now (advisory) | automatic |
| inventory/ | automatic scans: files, scripts, envs, git, jobs, drift reports | handoff.sh rescan |
| imports/ | work done OUTSIDE this server (Claude web chats, laptops): reports + code, one folder per person/source | added by hand, then reconciled |
| bin/handoff.sh | the helper script (shared copy, so both users run the same version) | |

Helper: `.handoff/bin/handoff.sh status`
EOF
  write_if_absent "$H/STATE.md" <<EOF
# STATE — $P
_Last rewritten: (not yet) — rewrite this whole file at every handoff, keep it to ~1 page_

## Goal

## Current stage

## Last completed step

## Next step (exact command)

## Known problems / open questions

## Do-not-touch (in use or final)
EOF
  write_if_absent "$H/CHECKPOINT.md" <<'EOF'
# CHECKPOINT — work in progress
_Updated: (never)_

Status: IDLE
Owner: -
Task: -

## Plan (sub-steps)

## Currently doing

## Runs started for this task

## Uncommitted / half-edited files

## Exact next action

## Resume notes
EOF
  write_if_absent "$H/LOG.md" <<EOF
# LOG — $P
Append-only. Newest entries at the BOTTOM. One entry per action. Never edit old entries; add a correction entry instead.
Entry header: ### <time> | <user>@<host> | <TYPE> | <title>
TYPES: ADOPT IMPORT RESUME RUN EDIT RESULT DECISION FAIL NOTE STOP TAKEOVER HANDOFF
EOF
  write_if_absent "$H/PIPELINES.md" <<'EOF'
# PIPELINES — registry of every script / pipeline step
Status: done | partial | running | failed | planned | obsolete.  Evidence: [verified] [inferred] [stated by NAME]

| id | script (path) | purpose | inputs | outputs | status | last run (run id / date) | evidence |
|---|---|---|---|---|---|---|---|
EOF
  write_if_absent "$H/DECISIONS.md" <<'EOF'
# DECISIONS — why things were done this way (append; never delete — mark "superseded by #N")

<!-- ## D1 — YYYY-MM-DD — NAME — short title
Decision:
Why:
Alternatives rejected:
Affects: (scripts / outputs) -->
EOF
  write_if_absent "$H/TODO.md" <<'EOF'
# TODO

## Now

## Next

## Blocked / waiting

## Done
EOF
  [[ -e "$H/DATA_MANIFEST.tsv" ]] || printf 'path\trole\tsize_bytes\tmd5\trecorded_by\trecorded_at\tdescription\n' > "$H/DATA_MANIFEST.tsv"
  [[ -e "$H/RUNS.tsv" ]] || printf 'run_id\tuser\thost\tname\tstart\tend\tstatus\texit\tduration_s\tcwd\tcommand\n' > "$H/RUNS.tsv"
  write_if_absent "$H/.gitignore" <<'EOF'
runs/*/stdout.log
runs/*/stderr.log
runs/*/pid
runs/*/child_pid
runs/*/pid_host
inventory/files.tsv
inventory/files.prev.tsv
inventory/history_*.txt
.seen/
.write.lock
LOCK
LOCK.tmp
*.tmp
EOF
}
setup_git(){
  command -v git >/dev/null 2>&1 || { echo "git: not installed — history/rollback disabled (everything else works)"; echo none > "$H/.git_mode"; return; }
  if g rev-parse --git-dir >/dev/null 2>&1; then
    echo existing > "$H/.git_mode"
    echo "git: using the EXISTING repository ($(g rev-parse --show-toplevel)); only .handoff/ and already-tracked files will be auto-committed"
  else
    g init -q || { warn "git init failed"; echo none > "$H/.git_mode"; return; }
    g config core.sharedRepository group
    echo handoff-owned > "$H/.git_mode"
    if [[ -e "$ROOT/.gitignore" ]]; then
      warn "a .gitignore already exists; leaving it. Check it excludes big data files before committing."
    else
      cat > "$ROOT/.gitignore" <<'EOF'
# Created by project-handoff. WHITELIST: ignore everything, then allow code, configs, notes and .handoff.
# Data and results are NEVER committed (they stay on the server; DATA_MANIFEST.tsv records them).
*
!*/
!.gitignore
!*.R
!*.r
!*.Rmd
!*.qmd
!*.py
!*.ipynb
!*.sh
!*.bash
!*.smk
!Snakefile
!Makefile
!*.nf
!nextflow.config
!*.wdl
!*.pl
!*.jl
!*.sql
!*.yml
!*.yaml
!*.toml
!*.cfg
!*.ini
!*.md
!renv.lock
!requirements*.txt
!DESCRIPTION
!Dockerfile
!.handoff/**
.snakemake/
work/
renv/library/
__pycache__/
.ipynb_checkpoints/
.Rproj.user/
.venv/
venv/
node_modules/
EOF
    fi
    echo "git: created a new repository at $ROOT (code + .handoff only, data excluded by .gitignore)"
  fi
}
cmd_perms(){
  local out="$H/inventory/perms.txt"
  { echo "# Shared-permission check $(ts) as $(id -un) ($(id -Gn))"
    echo "project root: $(stat -c '%U:%G %A' "$ROOT")"
    local grp; grp="$(stat -c %G "$ROOT")"
    echo; echo "## top-level folders (owner:group perms)"
    find "$ROOT" -maxdepth 1 -mindepth 1 -printf '%u:%g %M %P\n' 2>/dev/null | sort -k3 | head -60
    echo; echo "## files/dirs (whole tree, excluding scan-excluded) that the GROUP cannot write"
    build_prune
    local nw; nw="$(find "$ROOT" \( "${PRUNE[@]}" \) -prune -o ! -perm -g+w -print 2>/dev/null | wc -l)"; echo "count: $nw"
    local nsg; nsg="$(find "$ROOT" \( "${PRUNE[@]}" \) -prune -o -type d ! -perm -g+s -print 2>/dev/null | wc -l)"; echo "dirs without setgid bit: $nsg"
    echo; echo "## suggested one-time fix (run by the OWNER of the files, or with sudo; group shown is the project root's group '$grp')"
    echo "#   both users must be members of group '$grp'  (check: id <user>)"
    echo "chgrp -R $grp '$ROOT'"
    echo "chmod -R g+rwX '$ROOT'"
    echo "find '$ROOT' -type d -exec chmod g+s {} +"
    echo "# and in each user's ~/.bashrc:   umask 002"
  } > "$out"
  cat "$out"
}
cmd_adopt(){
  local dir="" hist=0 md5=0
  while [[ $# -gt 0 ]]; do case "$1" in --history) hist=1; shift;; --md5) md5=1; shift;; -*) die "adopt: unknown option $1";; *) dir="$1"; shift;; esac; done
  [[ -n "$dir" ]] || die "usage: handoff.sh adopt PROJECT_DIR [--history] [--md5]"
  [[ -d "$dir" ]] || die "not a directory: $dir"
  ROOT="$(cd "$dir" && pwd -P)"; H="$ROOT/.handoff"
  # "adopted" = config.env exists. A .handoff/ that only holds imports/ (reports copied in before adoption) is fine.
  if [[ -f "$H/config.env" ]]; then die "$ROOT is already adopted (.handoff/config.env exists). Use: status / rescan"; fi
  [[ -w "$ROOT" ]] || die "you cannot write to $ROOT (fix permissions first)"
  mkdir -p "$H"/{inventory,runs,bin,imports,plans} || die "cannot create $H"
  load_config
  make_templates >/dev/null
  cp -f "$SELF" "$H/bin/handoff.sh"; chmod 775 "$H/bin/handoff.sh"
  scan_git; setup_git          # record the pre-existing git state first, then set up git
  scan_files; scan_derived; scan_env; scan_jobs
  (( hist )) && scan_history
  if (( md5 )); then
    echo "computing md5 for data files ≤ ${MD5_MAX_MB}MB (can take a while)…"
    { printf 'path\tmd5\n'; awk -F'\t' -v re="$CODE_RE" -v max=$((MD5_MAX_MB*1024*1024)) 'NR>1 && $1 !~ re && $2<=max {print $1}' "$H/inventory/files.tsv" | \
      while IFS= read -r p; do printf '%s\t%s\n' "$p" "$(md5sum "$ROOT/$p" 2>/dev/null | cut -c1-32)"; done; } > "$H/inventory/checksums_baseline.tsv"
  fi
  cmd_perms > /dev/null
  local nfiles nscripts tot newest oldest
  nfiles=$(( $(wc -l < "$H/inventory/files.tsv") - 1 ))
  nscripts=$(( $(wc -l < "$H/inventory/scripts.tsv") - 1 ))
  tot="$(awk -F'\t' 'NR>1{s+=$2} END{printf "%.1f", s/1073741824}' "$H/inventory/files.tsv")"
  oldest="$(awk -F'\t' 'NR>1{print $4}' "$H/inventory/files.tsv" | sort -n | head -1)"; newest="$(awk -F'\t' 'NR>1{print $4}' "$H/inventory/files.tsv" | sort -n | tail -1)"
  write_if_absent "$H/BASELINE.md" <<EOF
# BASELINE — what existed when project-handoff was adopted
_Adopted: $(ts) by $(me)@$(host)_

Automatic scan: $nfiles files ($tot GB), $nscripts code files, file dates from $( [[ -n "$oldest" ]] && date -d @"$oldest" +%F ) to $( [[ -n "$newest" ]] && date -d @"$newest" +%F ).
Raw scan data: inventory/ (dir_summary.tsv, scripts.tsv, data_timeline.tsv, io_hints.tsv, envs.txt, git.txt, jobs.txt, perms.txt)

Evidence tags — use one on every claim:
[verified] checked in files/logs   [inferred] reconstructed from file names/dates/code   [stated by NAME] a person said so   [unknown]

## 1. Project goal

## 2. Folder layout (as it is — do NOT reorganise mid-project)

## 3. Inputs (raw data, references, external paths)

## 4. Work done so far, in order (reconstructed pipeline)
| step | script | inputs | outputs | done? | who | evidence |
|---|---|---|---|---|---|---|

## 5. Canonical vs. obsolete files (which version is the real one)

## 6. Software environment

## 7. Jobs running at adoption time

## 8. Open questions for the team (answer, then move answers into sections above)
EOF
  printf 'Adopted mid-project. Scan: %s files, %s code files, %s GB.\nSee BASELINE.md (to be completed) and inventory/.\n' "$nfiles" "$nscripts" "$tot" | append_log ADOPT "project-handoff adopted on existing project"
  CODE=1 do_commit "adopt: baseline snapshot of existing code + handoff files"
  echo "ok: adopted · helper: $H/bin/handoff.sh$(gitnote)"
  cmd_summary
  local nw; nw="$(grep -m1 '^count:' "$H/inventory/perms.txt" | awk '{print $2}')"
  [[ "${nw:-0}" != 0 ]] && warn "$nw files/dirs are not group-writable — your colleague may not be able to edit them. See $H/inventory/perms.txt"
  return 0
}

# ---- dispatch -------------------------------------------------------------------------
[[ "${1:-}" == --root ]] && { ROOT="$2"; shift 2; }
cmd="${1:-help}"; shift || true
case "$cmd" in
  adopt|init) cmd_adopt "$@";;
  version) echo "handoff.sh $HV";;
  help|-h|--help) awk 'NR>2 && /^# =====/{exit} NR>2' "$SELF" | sed 's/^# \{0,1\}//';;
  _exec) setup; cmd__exec "$@";;
  status|brief|rescan|lock|heartbeat|unlock|takeover|log|checkpoint|cp|plan|run|runs|show|stop|manifest|commit|end|perms|history|summary|io)
    setup
    case "$cmd" in
      status) cmd_status;; rescan) cmd_rescan "$@";; lock) cmd_lock "$@";; heartbeat) heartbeat_if_mine; echo "heartbeat: $(lock_state)";;
      unlock) cmd_unlock;; takeover) cmd_takeover "$@";; log) cmd_log "$@";; checkpoint) cmd_checkpoint "$@";;
      run) cmd_run "$@";; runs) cmd_runs "$@";; show) cmd_show "$@";; stop) cmd_stop "$@";;
      manifest) cmd_manifest "$@";; commit) cmd_commit "$@";; end) cmd_end "$@";; perms) cmd_perms;; history) scan_history;;
      brief) cmd_brief "$@";; cp) cmd_cp "$@";; plan) cmd_plan "$@";; summary) cmd_summary;; io) cmd_io "$@";;
    esac;;
  *) die "unknown command '$cmd' (try: handoff.sh help)";;
esac
