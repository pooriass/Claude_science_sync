# File formats (open only when unsure how to word something)

Short, plain, specific: numbers, paths, names. A note must make sense to someone who never saw
the chat. Bad: "fixed the bug". Good: "02_rctd.R: drop spots with <50 UMIs before RCTD (crashed on empty spots)".

## LOG entry — `HS log TYPE "title" -m "body"`

Body = 1–3 lines with only what applies: command/run id, inputs → outputs, parameters,
result or error cause, next. RUN start/finish, PLAN, STEP, TAKEOVER, STOP and HANDOFF entries are
written by the helper; don't duplicate them.

```
HS log RESULT "RCTD P04 checked" -m "results/rctd/P04_weights.csv: 3,812 spots x 14 types; myCAF/iCAF separate"
HS log FAIL "RCTD P06 out of memory" -m "run 20261014-0912_rctd_p06 DIED at 31 GB; rerun with 4 cores"
```

Types: EDIT · RESULT · DECISION · FAIL · NOTE · IMPORT (helper-written: ADOPT RUN PLAN STEP STOP TAKEOVER HANDOFF).

## CHECKPOINT — `HS cp`

Fields (pass only those that change): `--status` IDLE|IN_PROGRESS|PAUSED|BLOCKED · `--task` ·
`--plan "NN step k/n"` · `--doing` · `--runs "<run ids>"` · `--edited "<file: what is missing>"` ·
`--next "<exact command or check>"` · `--note` · `--clear` (empties plan/doing/runs/edited/next/notes).
`--next` must be runnable or checkable as written, never "continue the analysis".

## STATE.md — edit only changed lines

Sections: Goal · Current stage (1–2 lines) · Next step (exact command) · Known problems / open
questions · Do-not-touch. Running jobs are not listed here; `HS brief` shows them live.

## DECISIONS.md entry (append)

```
## D3 — 2026-10-13 — Sara — RCTD k = 8
Decision: k=8 reference clusters. Why: k=6 merged myCAF and iCAF.
Rejected: k=10 (split classical cells without reason). Affects: 01b_build_ref.R, all RCTD outputs.
```

Plan amendments (`HS plan amend`) are already logged as DECISION; add a DECISIONS.md entry only
for choices that outlive one plan.

## PIPELINES.md row

`| 03 | scripts/03_merge.R | merge per-sample RCTD weights | results/rctd/*_weights.csv | results/rctd_all.csv | done | 20261014-1012_merge | [verified] |`
