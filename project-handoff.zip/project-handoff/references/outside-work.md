# Work done outside the server (Claude web chats, laptops, other machines)

The server scan only sees files on the server. Work done in a **Claude web chat (claude.ai)** ran
in that chat's own temporary sandbox, not on the server. Its code, results and decisions exist
only in the chat — unless someone downloaded them and copied them to the server. The same is true
for work on a laptop. This file explains how to bring that work in, so BASELINE.md covers
everything.

## 1. Collect: one report per person per source (done by each person, in their own account)

Each person opens **their own** claude.ai account and pastes the prompt below. If the project
chats were inside a claude.ai Project, paste it inside that Project; chat search is limited to
the current Project, or to non-Project chats when used outside. Run it once in each place.
If Claude Science can see its earlier sessions, run the same prompt there too. If it cannot,
the server scan covers the files from those sessions.

The person then downloads (a) the report and (b) every code file / table / figure the report
lists, and copies them to the server:

```
<project>/.handoff/imports/<name>_<source>/        e.g.  ali_web/   sara_web/   sara_laptop/
    report.md
    code/      (scripts exactly as downloaded — do not rename)
    outputs/   (small tables/figures only; big data stays where it is and is described in report.md)
```

Create the folder with group-write permission (`mkdir -p` + `chmod -R g+rwX`).

### Prompt to paste in each claude.ai account (edit the keywords line)

```
Search my past chats about this research project and write ONE report as a downloadable
Markdown file named report.md.
Keywords to search (use each one): <project name>, <dataset names>, <methods, e.g. Visium,
RCTD, CellCharter, Seurat, Scanpy>, <sample names>, <key gene names>.

Rules: include only what is actually in the chats. Mark anything you are not sure of [unsure].
Do not invent results. Keep my own decisions separate from your past suggestions (write
"Claude suggested" vs "I decided").

Format:
# Web-work report — <my name> — <today's date>
## Chat list
| date | chat title | link | topic |
## For each chat (oldest first)
### <date> — <title> — <link>
- Goal:
- Data used: which files, which samples, uploaded full data or a subset? where did they come from?
- Where code ran: (a) here in the chat sandbox on uploaded data, or (b) I copied it to run
  elsewhere (server / laptop), or (c) not run
- Code produced: file names + purpose (attach the FINAL version of each file)
- Parameters / settings:
- Results: key numbers, figures, tables (file names I downloaded)
- Decisions I made and why:
- Failed attempts / errors:
- Open next steps at the end of the chat:
## All code files to download (final versions)
## Contradictions between chats (e.g. parameter changed later)
```

## 2. Reconcile (done on the server, during or after ADOPT)

`HS brief` lists every `imports/<folder>` that has no `RECONCILED` file yet.

For each import folder, read `report.md`. Then sort each item into one of these classes:

| Class | What it is | What to do |
|---|---|---|
| A. Code also on the server | a web script that was later copied to the server | `diff` the import copy against the server copy. Record which one is canonical in BASELINE §5. If they differ, ask which one made the existing outputs |
| B. Code only in the web chat, **run there** | analysis run in the chat sandbox on uploaded data | Results are **not reproducible yet**: different package versions, maybe a data subset. Copy the code into the project's code folder (with the user's yes), commit it, and **rerun on the server with `HS run`**. Until then, PIPELINES status = `web-only, rerun needed` |
| C. Code only in the web chat, **never run** | draft code | List in TODO as a candidate. Do not treat it as done |
| D. Results/figures with no matching code | a downloaded figure or table | Mark `[unknown provenance]`. Do not use it as final until it is regenerated on the server |
| E. Decisions / parameter choices | "we chose k=8 because…" | Add to DECISIONS.md, tagged `[web-chat: NAME, DATE]` |
| F. Conflicts | two sources disagree (parameter, version, sample list) | Put under BASELINE §8 *Open questions* and ask both people. Never pick one silently |

Tag every BASELINE/PIPELINES line that comes from an import with its source:
`[web-chat: Ali, 2026-09-14]`, `[claude-science: Sara]`, `[laptop: Sara]`.

When an import folder is done: `HS log IMPORT "reconciled imports/<folder>" -m "<counts per class; what needs a rerun>"`
Then `touch .handoff/imports/<folder>/RECONCILED`
and run `HS commit "reconcile <folder>"`.

## 3. Several copies of the project on the server

If the two Claude Science accounts worked in **different folders** (e.g. `/home/ali/proj` and
`/home/sara/proj`):
1. With both people, choose ONE folder as canonical. This is usually the one with the most complete
   raw data. Adopt that one.
2. Compare the other folder without changing anything:
   `rsync -rcn --out-format='%n' OTHER/ CANONICAL/` lists the files that differ or are missing, and
   `diff -rq OTHER/scripts CANONICAL/scripts` compares the code.
3. Treat the other folder like an import (classes A–F above). Copy items over only with the
   owner's yes, and log every copy as an `IMPORT` entry.
4. After that, everyone works only in the canonical folder. Put the old folder's path in
   `config.env → EXTRA_PATHS` until it is archived.

## 4. Rule from now on

- **Anything that produces a result runs on the server** through `HS run`, so it is logged and
  reproducible.
- Claude web chats are fine for thinking, reading papers, drafting code and writing text. But if
  web work produces code or a decision that the project uses, copy it into the project the same
  day and log it with `HS log IMPORT "<what>"`. Code goes into the code folder and gets committed.
  Decisions go into DECISIONS.md.
- A web chat cannot read the server's `.handoff/` files. Before you discuss the project in a web
  chat, paste in `STATE.md`, or the part of it you need, so the chat starts from the real state.
