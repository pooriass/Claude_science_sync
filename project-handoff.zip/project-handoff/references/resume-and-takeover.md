# Resuming an interrupted task (yours or the other person's)

Read when `HS brief` shows: a checkpoint IN_PROGRESS/PAUSED by someone else, a DIED/FAILED/KILLED
run, uncommitted code, or an open plan with steps left. Aim: continue without redoing finished
work and without trusting half-finished work.

## 1. Facts first (no changes yet) — usually 1–3 calls

- The brief already gave: checkpoint fields, open plans, runs, uncommitted files, unlogged file
  changes. Only fetch what is still unclear:
  - a plan's steps and parameters: `HS plan show NN` (skips the long rationale)
  - a run: `HS show RUN_ID` (error-like lines + short tails)
  - a half-edit: `git -C <project> diff --stat`, then `git diff <file>` for the file named
- The real state is the checkpoint **or one sub-step further** (it is written before each step).

## 2. Decide per item

| Run status | Action |
|---|---|
| RUNNING | Don't relaunch. Note expected end; do something independent or stop. |
| RUNNING(on HOST: cannot verify) | SLURM/other node: `squeue -j ID` / `sacct -j ID` (id in the run's `meta`). |
| DONE | Verify outputs (exist, sane size, open the head). Then `HS plan step NN k done -m "…" --run ID`. Exit 0 ≠ correct content. |
| FAILED | `HS show ID` → cause in one line → `HS plan step NN k failed -m "cause"` or `HS log FAIL`. Fix, commit, rerun as a new run. |
| KILLED | Read the STOP entry for why. Outputs suspect. |
| DIED | Gone without exit (kill -9, out of memory, reboot). Outputs suspect, likely half-written. Rerun the step (skip-if-exists keeps finished samples); if memory, reduce cores/chunk size and log `FAIL` with the cause. |

Suspect output = written by a run that did not end DONE. Check size vs siblings, load the head,
count rows before reuse; never `manifest … final` without checking.

Half-edited code: tell the user in 2–3 lines what was being changed and what the checkpoint says
is missing. Small and clear → finish it and `HS commit "finish X (started by NAME)"`. Unclear →
ask. Revert only with the user's yes (`git checkout -- <file>`) and `HS log NOTE` why.
Never run a pipeline on uncommitted code.

Unlogged file changes (brief's FILES line): `HS log NOTE "found at resume, not in LOG" -m "<files>"`.
If they look like outputs of an unknown process, check `ps`/`squeue` before touching them.

## 3. Take over and continue

1. Lock held by the other person and active → only after the user confirms they stopped:
   `HS takeover --reason "<user's words>"`. Stale → `HS takeover --reason "stale lock"`.
2. `HS cp --status IN_PROGRESS --task "…" --plan "NN step k/n" --next "<corrected next action>"`
   (Owner becomes you automatically).
3. Continue with the plan steps (SKILL.md §2).

## Two people working at the same time

The lock is for one main task, not all work. Agree (through the users) on separate areas:
different scripts and output folders. The second person does not take the lock and keeps their
own write-ahead note with `HS cp --personal …` (file `CHECKPOINT_<name>.md`); the brief lists it.
LOG, RUNS and MANIFEST appends are locked with `flock`, so simultaneous writes are safe.
