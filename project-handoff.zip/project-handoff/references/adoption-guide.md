# Adoption — first use on a project (new or half-done)

Goal: add `.handoff/` and reconstruct what was already done, **changing nothing in the project**.
One-time cost; still keep it lean: work from `HS summary` and `HS io`, not from raw scan files.

## Steps

1. Ask once (one message): project path; both names; may you scan the user's **own** shell
   history (`--history`)? data outside the folder? **where else work happened** (Claude web
   chats, laptops, other server folders)?
2. `bash <skill>/scripts/handoff.sh adopt <DIR> [--history]` (`--md5` only if the user wants
   checksums now — slow). It ends by printing a compact summary: folders, scripts in date order,
   paths each script mentions, data by folder, environment, git, running jobs, imports.
   Put outside paths into `.handoff/config.env` → `EXTRA_PATHS`.
3. Rules: do not move, rename, delete or reorganise anything (scripts contain paths). Don't clean
   up duplicates (`_old`, `_v2`); record which one is canonical.
4. Reconstruct the pipeline from the summary. For detail use `HS io <script> …` (only the
   library/read/write/save lines) and `grep`/`head` on `inventory/*.tsv`. Read a whole script only
   when its IO lines are not enough.
   - output exists, newer than its script → `done [inferred]`
   - output older than the script's last edit → `done with an older version? [inferred]`
   - output missing → `[unknown]`; much smaller than siblings → `possibly incomplete [inferred]`
   - notebooks: check saved outputs and execution order (often run out of order)
5. Outside work exists → follow `outside-work.md` (imports in `.handoff/imports/`).
6. Write `BASELINE.md` (sections are templated) and a row per script in `PIPELINES.md`.
   Tag every claim: `[verified]` `[inferred]` `[stated by NAME]` `[unknown]` `[web-chat: NAME, DATE]`.
7. Ask only what the scan could not answer, in one numbered message so the user can reply briefly.
   Pick from: goal in 1–2 sentences · who does which part · is this step order right? · which of
   these duplicates is canonical? · which outputs are final vs exploratory? · steps run elsewhere?
   · key parameters and why · where raw data came from · which env runs the scripts · anything
   running or half-done now? · the next step · known bugs or failed attempts.
   Record answers as `[stated by NAME]`; keep `[unknown]` when nobody knows.
8. Fill `STATE.md` and `TODO.md`. `HS manifest <path> raw|reference|final "desc"` for raw inputs and
   final outputs (not every intermediate).
9. Running jobs found at adoption (not started with `HS run`): don't restart them. Put PID/SLURM id,
   expected output and how to check into STATE.md *Known problems / open questions*.
10. If the summary shows files not group-writable: show the user the fix commands in
    `inventory/perms.txt`; run `chgrp`/`chmod` only with the user's yes.
11. `HS log NOTE "baseline reconstructed" -m "3 lines"`, then `HS end -m "adopted"`.
12. Tell the user the colleague should start with *"Resume <path>, then go through BASELINE.md with
    me and correct my parts"*.

## Second person on an already-adopted project

`HS brief`, then walk through BASELINE.md lines about their work. Never delete earlier text;
correct beside it: `~~[inferred] run by Ali~~ [stated by Sara] run by Sara on 2026-09-28`.
With consent, `HS history` saves the lines of their **own** history that concern the project
(secret-looking lines dropped; git-ignored).

## Several copies of the project on the server

Choose one canonical folder with both people. Compare without changing anything:
`rsync -rcn --out-format='%n' OTHER/ CANONICAL/` and `diff -rq OTHER/scripts CANONICAL/scripts`.
Treat the other folder like an import (`outside-work.md` classes A–F); copy items only with the
owner's yes and log each copy as `IMPORT`. Put the old path in `EXTRA_PATHS` until archived.
