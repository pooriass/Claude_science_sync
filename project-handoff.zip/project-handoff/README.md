# project-handoff — quick start for the two of you

## 1. Install (both accounts)
Add this whole folder as a skill in **each** Claude account (yours and your colleague's).
The skill folder must contain `SKILL.md`, `scripts/` and `references/`.

## 2. One-time server setup (once, by whoever owns the files)
Both Unix users must be in the same group (e.g. `lab`), and files must be group-writable:
```
chgrp -R lab /path/to/project
chmod -R g+rwX /path/to/project
find /path/to/project -type d -exec chmod g+s {} +
echo 'umask 002' >> ~/.bashrc      # each user, once
```
After adoption, `.handoff/inventory/perms.txt` shows whether this is right.

## 3. What to type

| When | Message to Claude |
|---|---|
| First time, project already half-done | "Use project-handoff to adopt /path/to/project" |
| Start of every session | "Resume /path/to/project" |
| You agreed on a pipeline | "Apply this pipeline" (Claude saves it as a plan, shows it, runs after your yes) |
| Save a pipeline for later / for your colleague | "Save this pipeline as a plan, don't run it yet" |
| After something important | (Claude logs automatically; you can say "log this") |
| Stopping | "Handoff" |
| Tokens almost gone | "Emergency handoff" |
| Colleague stopped mid-task | "Resume /path/to/project — Ali ran out of tokens, continue his task" |

## 4. Where things are
Everything is in `/path/to/project/.handoff/`. Start with `README.md` there.
Helper: `/path/to/project/.handoff/bin/handoff.sh brief` (you can run it yourself in a terminal).
